#include<stdio.h>
int main(){
    int a,b,c;
    int max;
    printf("enter value a&b&c");
    scanf("%d %d %d",&a,&b,&c);

 max=(a>b &&a>c)?printf("a=%d is a grater number",a):(b>a && b>c)?printf("b=%d is gratter number",b):printf("c=%d is gratter number",c);

    

return 0;
}