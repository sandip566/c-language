#include<stdio.h>
int main(){
    int a,b;
    int even;
    printf("enter value a&b");
    scanf("%d %d",&a,&b);

   even=a==b?printf("A %d is equal to B %d",a,b):printf("A %d is not equal B %d",a,b);

return 0;
}