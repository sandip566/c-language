#include<stdio.h>
int main(){
    char ch;

    printf("enter a charcter ");
    scanf("%c",&ch);

   (ch>='a' && ch<='z' ||ch>='A' && ch<='Z')?printf("%c \n this is charcater",ch):printf(" %ch this is number",ch);

return 0;
}