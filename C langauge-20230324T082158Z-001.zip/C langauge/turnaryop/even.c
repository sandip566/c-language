#include<stdio.h>
int main(){
    int a;
    int even;
    printf("enter value a");
    scanf("%d",&a);

 even=a%2==0?printf("this is even %d",a):printf("this is odd %d",a);

return 0;
}