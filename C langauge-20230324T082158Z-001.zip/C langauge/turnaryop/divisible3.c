#include<stdio.h>
int main(){
    int a;

    printf("enter a number");
    scanf("%d",&a);

    (a%3==0)?printf("a=%d is divisible by three",a):printf("a=%d is not divisible by three",a);

    return 0;
}