#include<stdio.h>
int main(){
    int a,b;
    int max;
    printf("enter value a&b");
    scanf("%d %d",&a,&b);

 max=(a>b)?a:b;
    printf("%d",max);

return 0;
}