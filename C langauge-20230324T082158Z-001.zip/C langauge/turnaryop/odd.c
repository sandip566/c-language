#include<stdio.h>
int main(){
    int a;
    int even;
    printf("enter value a");
    scanf("%d",&a);

 even=a%2==0?0:1;
    printf("%d",even);

return 0;
}