#include <stdio.h>
int main(){
    char c;
    printf("enter a character");
    scanf("%c",&c);
    if(c>='0'&&c<='9'){
        printf("the character is digit\n");
    }else{
        printf("the character is not digit\n");
    }
    return 0;
}