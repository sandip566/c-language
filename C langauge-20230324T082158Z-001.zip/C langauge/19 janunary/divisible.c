# include <stdio.h>
int main(){
    int num;
    printf("enter a num");
    scanf("%d",&num);
    switch(num%2==0){
        case 1:
        printf("its a divisible num");
        break;
        case 0:
        switch( num%2==1){
   case 1:
  printf("not a divisible num");
  break;
  default:
  printf("none");
  break;
        }
     
    }
    return 0;
}