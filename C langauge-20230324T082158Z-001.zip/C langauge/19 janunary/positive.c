#include<stdio.h>
int main(){
    int a;
    printf("enter num");
    scanf("%d",&a);
    switch(a>0){

    case 1:
    printf("positive num");
    break;

    case 0:
    switch(a<0){
    case 1:
    printf("negative num");
    break;

    default:
    printf("invalid");
    break;
    }
    break;
    }
    return 0;
}