#include<stdio.h>
int main(){
    int age;
    printf("enter age");
    scanf("%d",&age);
    switch(age>18){
        case 1:
        printf("elagible for vote");
        break;
        case 0:
        switch(age<18){
            case 1:
            printf("not vote ");
            break;
            default:
            printf("invalid");
            break;
        }
    }
    return 0;
}