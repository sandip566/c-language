#include <stdio.h>
int main(){
    int month;
    printf("enter your month");
    scanf("%d",&month);
   switch(month){
      case 1:
      printf("jan 29 days");
      break;
      case 2:
      printf(" feb 30 days ");
      break;
       case 3:
      printf(" march 40 days ");
      break;
       case 4:
      printf(" april 30 days ");
      break;
       case 5:
      printf(" may 30 days ");
      break;
       case 6:
      printf(" june 28 days ");
      break;

       case 7:
      printf(" july 28 days ");
      break;
       case 8:
      printf(" aug 20 days ");
      break;
       case 9:
      printf(" sep 34 days ");
      break;
       case 10:
      printf(" oct 31 days ");
      break;
       case 11:
      printf(" nov 25 days ");
      break;
       case 12:
      printf(" dec 20 days ");
      break;
       

   }  
  return 0;
  }