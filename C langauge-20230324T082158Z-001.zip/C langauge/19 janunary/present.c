# include <stdio.h>
int main(){
    int num;
    printf("enter name");
    scanf("%d",&num);
    switch(num){
        case 1:
        printf("sushant");
        break;
        case 2:
        printf("adesh");
        break;
        case 3:
        printf("rahul");
        break;
        default:
        printf(" invalid ");
        break;
    }
    return 0;
}