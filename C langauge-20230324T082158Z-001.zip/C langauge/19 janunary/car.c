#include<stdio.h>
int main(){
    int car;
    printf("enter your car num ");
    scanf("%d",&car);
    switch(car){
        case 1:
        printf("swift");
        break;
        case 2:
        printf("bolero");
        break;
         case 3:
        printf("scorpio");
        break;
    }
    return 0;
}