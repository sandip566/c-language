#include<stdio.h>
int main(){
    int id;
    int password;
    printf("enter your id\n");
    scanf("%d",&id);
    switch(id){
  printf("enter your password\n");
  scanf("%d",&password);
  switch(password){
    case 1100;
    printf("welcome
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    ")
  }
    }

   

}