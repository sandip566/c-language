#include <stdio.h>
int main(){
    int a,b,c;
    a=10;
    b=20;
    c=a+b;
    printf("%d is a addition of two number",c);
    return 0;
}