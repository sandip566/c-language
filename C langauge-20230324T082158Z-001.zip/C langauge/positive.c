#include <stdio.h>
int main(){
    int a;
    printf("enter an integer");
    scanf("%d",&a);
    if(a>=0){
        printf("%d is a positive number",a);
    }else if(a<=0){
        printf("%d number is negative",a);
    }else{
        printf("%d error");
    }
    return 0;
}