// #include <stdio.h>
// int main(){
//     int a,b,c,d;
//     printf("enter first value\n");
//     scanf("%d",&a);
//     printf("enter second value\n");
//     scanf("%d",&b);
//     printf("enter third value\n");
//     scanf("%d",&c);
//     d=(a+b+c);
//     printf("%d is addition of three number",d);
//     return 0;
// }
#include <stdio.h>
int main(){
    int a,b,c;
    printf("enter 2 value");
    scanf("%d %d",&a,&b);
    c=a+b;
    printf("%d is a addition",c);
}