#include<stdio.h>
int main() {

    int a,b,c;

    printf("enter a number A & B");
    scanf("%d %d",&a,&b);
   c=a;
   a=b;
   b=c;
   //a=b;
  // b=c;
  // c=a;

    
    printf("swapping A=%d & B=%d ",a,b);

    return 0;
}