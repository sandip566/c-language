#include<stdio.h>
int main(){
    int x=10;
    int y=4;
    printf("%d",x>y);
    return 0;
}