#include<stdio.h>
int main(){
    int x=200;
    int y=100;
    printf("%d",x-y);
    return 0;
}