//program of -= oprator

#include<stdio.h>
int main(){
    int x=15;

    printf("%d",x-=5);
    return 0;
}