//program of x- oprator

#include<stdio.h>
int main(){
    int x=10;
    printf("%d",x-6);
    return 0;
}