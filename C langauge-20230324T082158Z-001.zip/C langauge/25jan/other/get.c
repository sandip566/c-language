#include<stdio.h>
int main(){
    int get;
    printf("enter code");
    scanf("%d",&get);
    switch(get>100){
        case 1:
        printf("good");
        break;
        case 0:
        switch(get<100){
            case 1:
            printf("bad");
            break;
        }
    }
    return 0;
}