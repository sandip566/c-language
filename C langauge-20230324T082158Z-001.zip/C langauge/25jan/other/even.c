#include<stdio.h>
int main(){
    int a;
    printf("enter a num\n");
    scanf("%d",&a);
    switch(a%2==0){
        case 1:
        printf("this is even num");
        break;
        case 0:
        switch(a%2==1){
            case 1:
            printf("this is odd num");
            break;
        }
    }
    return 0;
}