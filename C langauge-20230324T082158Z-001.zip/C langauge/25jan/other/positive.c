#include<stdio.h>
int main(){
    int mark;
    printf("enter a num");
    scanf("%d",&mark);
    switch(mark>0){
        case 1:
        printf("positive num");
        break;
        case 0:
        switch(mark<0){
        case 1:
        printf("negative num");
        break;
        }
    }
    return 0;
}