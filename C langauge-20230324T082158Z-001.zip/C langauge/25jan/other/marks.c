#include<Stdio.h>
int main(){
    int marks;
    marks=31;
    switch(marks>35){
        case 1:
        printf("passed");
        break;
        case 0:
        switch(marks<35){
            case 1:
            printf("failed");
            break;
        }
        
}
   return 0;
}