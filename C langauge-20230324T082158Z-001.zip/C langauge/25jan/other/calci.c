#include<stdio.h>
int main(){
    char op;
    printf("enter op +,-,*,/");
    scanf("%c",&op);
    int a,b;
    printf("enter two number");
    scanf("%d %d",&a,&b);
    switch(op){
        case '+':
        printf("addition is= %d+%d=%d",a,b,a+b);
        break;
        case '-':
        printf("substract is= %d-%d=%d",a,b,a-b);
        break;
        case '*':
        printf("multi is=%d*%d=%d",a,b,a*b);
        break;
        case '/':
        printf("divide is = is=%d/%d=%d",a,b,a/b);
        break;
    }
    return 0;
}