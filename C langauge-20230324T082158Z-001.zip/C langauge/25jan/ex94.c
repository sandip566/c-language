#include<stdio.h>
int main(){
    int x=12;
    int y=20;
    printf("%d",x/y);
    return 0;
}