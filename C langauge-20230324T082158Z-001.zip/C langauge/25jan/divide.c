//  division of two num //

#include<stdio.h>
int main(){
    int x=10;
    int y=5;
    printf("%d ",x/y);
    return 0;
}