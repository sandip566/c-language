// program in -= op //

#include<stdio.h>
int main(){
    int x=10;
    int y=3;
    printf("%d",x<y);
    return 0;
}