#include<stdio.h>
int main(){
    int x=25;
    int y=20;
    printf("%d",x*=y);
    return 0;
}