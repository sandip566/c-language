#include<stdio.h>
int main(){
    int x=20;
    int y=11;
    printf("%d",x<y);
    return 0;
}