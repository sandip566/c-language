#include<stdio.h>
int main(){
    int x=27;
    int y=18;
    printf("%d",x%y);
    return 0;
}