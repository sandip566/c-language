#include<stdio.h>
int main(){
    int x=10;
    int y=32;
    printf("%d",x-=y);
    return 0;
}