#include<stdio.h>
int main(){
    int x=5;
    int y=3;
    printf("%d",x>3||x<5);
    return 0;
}