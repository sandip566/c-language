#include<stdio.h>
int main(){
    int x=100;
    int y=200;
    printf("%d",x+y);
    return 0;
}