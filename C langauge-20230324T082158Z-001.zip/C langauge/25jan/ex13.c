// program in *= op //

#include<stdio.h>
int main(){
    int x=5;
    int y=7
    printf("%d",x>y);
    return 0;
}