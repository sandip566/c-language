#include<stdio.h>
int main(){
    int x,y;
     x=50;
     y=5;
    printf("%d",x/y);
    return 0;
}