//  program increment op in c //

#include<stdio.h>
int main(){
    int x=5;
    printf("%d",++x);
    return 0;
}