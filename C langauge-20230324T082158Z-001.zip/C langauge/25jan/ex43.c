#include<stdio.h>
int main(){
    int x=30;
    int y=20;
    printf("%d",x%y);
    return 0;
}