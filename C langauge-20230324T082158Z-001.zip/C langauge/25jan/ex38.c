#include<stdio.h>
int main(){

    int y=4;
    printf("%d",y);
    return 0;
}