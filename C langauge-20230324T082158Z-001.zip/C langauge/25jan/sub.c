#include <stdio.h>
int main(){
    int x=10;
    x-=5;
    printf("%d",x);
    return 0;
}