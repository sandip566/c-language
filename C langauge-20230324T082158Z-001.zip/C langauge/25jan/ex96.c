#include<stdio.h>
int main(){
    int x=21;
    printf("%d",++x);
    return 0;
}

