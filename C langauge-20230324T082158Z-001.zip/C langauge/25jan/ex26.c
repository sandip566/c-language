#include<stdio.h>
int main(){
    int x,y;
     x=10;
     y=4;
    printf("%d",x>y);
    return 0;
}