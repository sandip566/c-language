#include<stdio.h>
int main(){
    int a,b;

       printf("enter a two number");
       scanf("%d %d",&a,&b);

       if(a>b){
        printf("a is gratter than b");
       }
       else{
        printf("a is smaller than b");
       }
       return 0;
}