#include<stdio.h>
int main(){
    int rollno;
    int phy,chem,bio;
    int total,avarage;
    printf("enter a roll no");
    scanf("%d",&rollno);

     printf("enter a marks of phy");
    scanf("%d",&phy);

 printf("enter a  marks of chem");
    scanf("%d",&chem);

     printf("enter a marks of bio");
    scanf("%d",&bio);

    total=phy+chem+bio;
    avarage=total/3;

    if(avarage>60){
        printf("your passed &total marks= %d & you acheived 'A' grade",avarage);
    }
    else if(avarage>50 && avarage<60){
        
        printf("your passed &total marks= %d & you acheived 'B' grade",avarage);
    }
    else if(avarage>40 && avarage<50){

        
        printf("your passed &total marks= %d & you acheived 'c' grade",avarage);
    }



    return 0;


}