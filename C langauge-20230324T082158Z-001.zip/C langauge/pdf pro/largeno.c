#include<math.h>
int main(){
    int a,b,c;


       printf("enter a two number");
       scanf("%d %d",&a,&b);

c=Math.max(a,b);

printf("large no is %d",c);
return 0;

}