#include<stdio.h>
int main(){
    int num;
    char days[7]={"monday", "tuesday", "wednesday", "thursday" ,"friday", "saturday"};
    printf("Enter number (1 to 7)");
    scanf("%s",&num);

    printf("week %s",days[2]);

    return 0;
}

/*#include<stdio.h>
int main(){
    int arr[6]={10,20,30,40,50};
    printf("array %d",arr[2]);

    return 0;
}*/