#include<stdio.h>
int main(){
    int n,i;

    printf("enter a 4 numbers less than 10");
    scanf("%d %d %d %d",&n,&a,&b,&c);

    for(i=10;i>1;i--)

    return 0;
}