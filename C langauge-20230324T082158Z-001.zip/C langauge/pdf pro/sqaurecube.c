//to print square and cube
#include<stdio.h>
int main(){
    int a;
    int square,cube;

       printf("enter a number");
       scanf("%d",&a);

square=a*a;
cube=a*a*a;

printf("square & cube of number %d & %d",square,cube);

return 0;

}