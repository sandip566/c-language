#include<stdio.h>
int main(){
    int x,y,div;

    printf("enter a two number");
    scanf("%d %d",&x,&y);

    div=x/y;

    printf("division of two number is=%d",div);

    return 0;
}