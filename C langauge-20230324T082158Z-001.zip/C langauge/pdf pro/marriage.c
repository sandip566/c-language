#include<stdio.h>
int main(){
    char g;
    int age;

    printf("Enter Your Gender(m,f):");
    scanf("%c",&g);

    printf("Enter your age: ");
    scanf("%d",&age);

    if( g=='m'){

        if(age>=21){
        printf("You can marry"); 
    }
    
    else{
        printf("You can't marry");
    } 
    
}
else if(g=='f'){
    if(age>=18){
        printf("you are eligible for marry");
    }

    else {
        printf("you are not eligible for marry");
    }
}
else{
    printf("enter invalid data");
}
return 0;
}