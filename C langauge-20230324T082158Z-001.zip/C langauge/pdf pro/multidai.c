#include<stdio.h>
int main(){
    char days[7][10]={"monday","tue","wed","thur","fri","sat","sun"};

    printf(" %c",days[0][0]);
     printf(" %c",days[0][1]);
      printf(" %c",days[0][2]);
       printf(" %c",days[0][3]);
        printf(" %c",days[0][4]);
         printf(" %c",days[0][5]);

    return 0;

}