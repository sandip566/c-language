#include<stdio.h>
int main(){
    int radius,area;

       printf("enter a radius");
    scanf("%d",&radius);

float a=3.14;
area=a*radius*radius;

printf("area of circle %d",area);

return 0;

}