#include<stdio.h>
int main(){
    int height,base;
    int area;

       printf("enter youe height & base");
    scanf("%d %d",&height,&base);

float a=0.5;
area=a*base*height;

printf("area of triangle %d",area);

return 0;

}