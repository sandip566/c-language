
#include<stdio.h>
int main(){
    int a,b,c;

       printf("enter a two number");
       scanf("%d %d",&a,&b);

       printf("swaping a=%d,b=%d \n",a,b);

       c=a;
       a=b;
       b=c;

       printf("interchanging a=%d & b=%d ",a,b);
       return 0;
}