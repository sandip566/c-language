#include<stdio.h>
int main(){
    char arr[3][2]={"ab","pr","tu"};

    printf("array %s",arr[0]);
    return 0;
}

