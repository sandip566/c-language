#include<stdio.h>
int main(){
    int rollno;
    int phy,chem,bio;
    int total,avarage;
    printf("enter a roll no");
    scanf("%d",&rollno);

     printf("enter a marks of phy");
    scanf("%d",&phy);

 printf("enter a  marks of chem");
    scanf("%d",&chem);

     printf("enter a marks of bio");
    scanf("%d",&bio);

    total=phy+chem+bio;
    avarage=total/3;

    printf("avarage of total marks %d",avarage);

    return 0;


}