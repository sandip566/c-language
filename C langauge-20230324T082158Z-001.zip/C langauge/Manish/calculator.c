#include<stdio.h>
int main(){
    char op;
    int a,b;
    printf("enter a op(+,-,/,*)");
    scanf("%c",&op);
    printf("enter a two operater");
    scanf("%d %d",&a,&b);

    switch(op){
        case '+':
        printf("addition=%d",a+b);
        break;

        case '-':
        printf("addition=%d",a-b);
        break;

           case '/':
        printf("addition=%d",a/b);
        break;

           case '*':
        printf("addition=%d",a*b);
        break;
    }
    return 0;
}