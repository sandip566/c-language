#include<stdio.h>
int main(){
int arr[5]={5,3,4,1,2};
int max=arr[0];

for (int i=1;i<5;i++){
    if(arr[i]>max){
        max=arr[i];
    }
}
printf("Large element in the arrey:%d",max);
return 0;
}