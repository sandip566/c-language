#include<stdio.h>
int main(){
    int a=20;
    int b=30;
    int max;

(a>b)?a:b;
    printf("b=%d is grater than A ",b);

return 0;
}