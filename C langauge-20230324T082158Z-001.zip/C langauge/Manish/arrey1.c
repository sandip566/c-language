#include<stdio.h>
int main(){
    float marks[3];

    printf("enter a marks physics");
    scanf("%f",&marks[0]);

    printf("enter a marks maths");
    scanf("%f",&marks[1]);

     printf("enter a marks biology");
    scanf("%f",&marks[2]);

    printf(" phy=%f\n,maths=%f\n,biology=%f\n",marks[0],marks[1],marks[2]);
    return 0;
}