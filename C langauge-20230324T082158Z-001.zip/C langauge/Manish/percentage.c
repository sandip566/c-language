
#include<stdio.h>
int main(){
int a[6];
printf("enter your marks(phy,chem,bio,math,english,marathi) :-");
scanf("%d",&a[0]);
scanf("%d",&a[1]);
scanf("%d",&a[2]);
scanf("%d",&a[3]);
scanf("%d",&a[4]);
scanf("%d",&a[5]);

 int total=a[0]+a[1]+a[2]+a[3]+a[4]+a[5];
 int mark=total/6;
 printf("%d",mark);
 return 0;
}
