
#include<stdio.h>
int main(){
    int arr[5]={2,5,7,10,6};
    int sum=0;

    for(int i=0; i<5; i++){
        sum+=arr[i];
    }

    float avg=(float)sum/5;

    printf("average of array element:%.2f\n",avg);
    return 0;
}