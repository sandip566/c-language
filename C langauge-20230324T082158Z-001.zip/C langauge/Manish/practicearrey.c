#include <stdio.h>
int main(){
    let price[3]
    printf("enter a price");
    scanf("%d")
}