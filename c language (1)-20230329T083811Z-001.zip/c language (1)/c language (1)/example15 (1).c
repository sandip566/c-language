// write a program to accept three numbers from user and 
// print them in ascending and desanding order in c language

#include <stdio.h>
int main(){
    int a,b,c;
    printf("Enter numbers..");
    scanf("%d%d%d",&a,&b,&c);
    if ((a>=b)&&(a>=c))
    {
       if (b>=c)
       {
        printf("\n desanding order : %d %d %d",a,b,c);
        printf("\n Ascending order : %d %d %d",c,b,a);
       } 
else{
    printf("\n desanding order : %d %d %d",a,c,b);
        printf("\n Ascending order : %d %d %d",b,c,a);
}


    }
    else if((b>=a)&&(b>=c))
    {
        if(a>=c)
        {
            printf("\n desanding order : %d %d %d",b,a,c);
        printf("\n Ascending order : %d %d %d",c,a,b);
        }
        else {
            printf("\n desanding order : %d %d %d",b,c,a);
        printf("\n Ascending order : %d %d %d",a,c,b);
        }
    }
    else if((c>=a)&&(c>=b))
    {
        if(a>=b)
        {
            printf("\n desanding order : %d %d %d",c,a,b);
        printf("\n Ascending order : %d %d %d",b,a,c);
        }
        else {
            printf("\n desanding order : %d %d %d",c,b,a);
        printf("\n Ascending order : %d %d %d",a,b,c);
        }
    }
    return 0;
}