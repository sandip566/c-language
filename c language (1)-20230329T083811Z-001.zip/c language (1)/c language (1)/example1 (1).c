//write a program to accept values of teo numbers and print 
//their division in C language ?

#include <stdio.h>

int main()
{
    float a,b,c;
      printf("Enter number 1:");
    scanf("%f",&a);
    printf("Enter number 2:");
    scanf("%f",&b);
    c=a/b;
    printf("Division is :%f",c);
    
    

}